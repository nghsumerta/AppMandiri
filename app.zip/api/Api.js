export function getOrder(member_id,callback,error = () => {}){
    fetch('https://bebaskan.id/android/filterorder.php', {
      method: 'POST',
      headers: {
        'Accept' : 'application/json',
        'Content-Type' : 'application/json',
      },
      body: JSON.stringify({
        member_id : member_id
      })
    }).then(res => {
      return res.json();
    }).then(json => {
      callback(json);
    }).catch(err => {
        console.log(err);
    })
}
