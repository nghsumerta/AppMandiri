var initial = {
    order : [],
}

export function reducer(state = initial,action){
    switch(action.type){
        case "UPDATE":
            return {
                order : action.data
            }
        break;
        default:
            return state;
        break;
    }
}