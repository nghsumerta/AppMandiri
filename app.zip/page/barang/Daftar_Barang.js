import React, { Component } from 'react';
import { Image, View, ListView, ActivityIndicator, FlatList, Alert, Platform, TextInput, Button} from 'react-native';
import { Container, Header, Content, Card, CardItem, Thumbnail, Text, Icon, Left, Body, List, Label, Input, Item, ListItem, Right, Form } from 'native-base';
import { Ionicons } from '@expo/vector-icons';
import { TabNavigator, TabBarBottom, StackNavigator } from 'react-navigation';
import { Col, Row, Grid } from 'react-native-easy-grid';


class DaftarBarang extends Component {
 
    static navigationOptions = {
        title: 'Daftar Barang'
    };
   
   
    constructor(props)
    {
   
      super(props);
   
      this.state = {
   
          isLoading: true
     
      }
   
    }
   
    AmbilDataBarang(barang_id){
      this.props.navigation.navigate('Tiga', {
        
        BARANG_ID: barang_id
      });
    }
   
    componentDidMount() {
     
      fetch('https://bebaskan.id/android/filterkategori.php',{
        method: 'POST',
        headers: {
          'Accept' : 'application/json',
          'Content-Type' : 'application/json',
        },
        body: JSON.stringify({
          kategori_id: this.props.navigation.state.params.KATEGORI_ID,
        })
  })
           .then((response) => response.json())
           .then((responseJson) => {
             let ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
             this.setState({
               isLoading: false,
               dataSource: ds.cloneWithRows(responseJson),
             }, function() {
             
             });
           })
           .catch((error) => {
             console.error(error);
           });
       }
   
    render() {
   
      if (this.state.isLoading) {
        return (
   
              <View style={{
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'}}>
   
              <ActivityIndicator size="large" />
   
              </View>
        );
      }
   
      return (
   
          <View style={{
            justifyContent: 'center',
            flex:1,
            margin: 10,
          }}>
           
         
              <ListView
             
                  dataSource={ this.state.dataSource }                
   
                  renderRow={(rowData) =>            
                    <List>
                        <ListItem avatar>
                      <Left>
                        <Thumbnail source={{ uri: 'http://icons.iconarchive.com/icons/custom-icon-design/flatastic-7/256/Bookmark-add-icon.png' }} />
                      </Left>
                      <Body>
                          <Text onPress = { this . AmbilDataBarang . bind ( this ,  rowData . barang_id ) } >  { rowData . nama_barang }</Text>
                      </Body>
                      <Right>
                        <Text note >{rowData.stok}</Text>
                      </Right>                  
                      </ListItem>
                    </List>              
                  }
            />
        </View>            
      );
    }
  }

  
  export default DaftarBarang 