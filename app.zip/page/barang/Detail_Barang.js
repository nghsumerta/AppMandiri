import React, { Component } from 'react';
import { AsyncStorage, Image, View, ListView, ActivityIndicator, FlatList, Alert, Platform, TextInput, Button, Keyboard, KeyboardAvoidingView} from 'react-native';
import { Container, Header, Content, Card, CardItem, Thumbnail, Text, Icon, Left, Body, List, Label, Input, Item, ListItem, Right, Form } from 'native-base';
import { Ionicons } from '@expo/vector-icons';
import { TabNavigator, TabBarBottom, StackNavigator } from 'react-navigation';
import { Col, Row, Grid } from 'react-native-easy-grid';
import {getOrder} from '../../api/Api';
import {connect} from 'react-redux';



class Barang extends Component {
    static navigationOptions = {
      title : 'Detail Barang'
    };
   
    constructor(props){
      super(props)
   
      this.state = {
        Member_ID: '',
        NamaBarang : '',      
        StokBarang: '',
        HargaBarang: '',
        DeskripsiBarang: '',
        GambarBarang: '',
        InputJumlah: '',
        InputMember: '',
   
      }
    }




    order = () =>{

      let stock = parseInt(this.state.StokBarang);
      let order = parseInt(this.state.InputJumlah);
      if(stock <= 0){
        Alert.alert('Stock sedang kosong');
        return 0;
      }
      if(order > stock){
        Alert.alert('Stock tidak cukup dengan jumlah order');
        return 0;
      }
 
      fetch('http://bebaskan.id/android/order.php', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        member_id : this.state.MEMBER_ID,        
 
        barang_id : this.state.Barang_ID,
 
        jumlah : this.state.InputJumlah,
 
        stok: this.state.StokBarang, 

        harga : this.state.HargaBarang,
 
      })
 
      }).then((response) => response.json())
          .then((responseJson) => {            

            getOrder(this.state.MEMBER_ID,(json) => {
              this.props.dispatch({type:"UPDATE",data:json});
              Alert.alert(responseJson);
              this.componentDidMount();
              this.props.navigation.navigate('Order');
              
            })
            
 
          }).catch((error) => {
            console.error(error);
          });
 
}


    
    componentDidMount(){
      this.setState({
        InputJumlah : ''
      })
      fetch('https://bebaskan.id/android/filterkategori1.php',{
            method: 'POST',
            headers: { 
              'Accept' : 'application/json',
              'Content-Type' : 'application/json',
            },
            body: JSON.stringify({
              barang_id: this.props.navigation.state.params.BARANG_ID,
                        
            })
      })
      .then((response) => response.json() )
      .then((responseJson) => {
         

        
       
        AsyncStorage.getItem('idMember').then(id => {

        this.setState ({    
          MEMBER_ID : id,
          Barang_ID : responseJson[0].barang_id,    
          Kategori_ID : responseJson[0].kategori_id,
          NamaBarang : responseJson[0].nama_barang,
          HargaBarang : responseJson[0].harga_barang,
          GambarBarang : responseJson[0].gambar,
          StokBarang: responseJson[0].stok,
          DeskripsiBarang: responseJson[0].ket,
          KategoriBarang: responseJson[0].nama_kategori
        })
      })
    })
      .catch((error) =>{
        console.error(error);
       
      });
    }
   
    render()
    {
      
      return(
   
  
        <Container>
         
          <Content>
          <KeyboardAvoidingView behavior="padding">
             <Card style={{flex: 0}}>
  
              <CardItem>              
                  <Body>
                    <Text>
                        {'Kategori Barang : '+this.state.KategoriBarang}   
                        
                    </Text>
                   
                  </Body>           
              </CardItem>
  
            </Card>
  
               
            <Card>
              <CardItem>
                <Body style={{alignItems:'center', flexGrow:1, justifyContent:'center', margin:10}}>
                  <Image source={{uri: 'http://bebaskan.id/gambar/'+this.state.GambarBarang}} style={{height: 300, width: 250, flex: 1, borderRadius:30}}/>
                </Body>
              </CardItem>            
            </Card>
            <Card>
  
            <Card>
              <CardItem style={{backgroundColor:'red'}}>              
                <Body style={{alignItems:'center', flexGrow:1, justifyContent:'center'}}>                  
                  <Text style={{color:'white', fontSize: 20}}>
                  {this.state.NamaBarang} 
                  </Text>
                </Body>           
              </CardItem>
            </Card>
  
            <Card style={{flex: 0}}>
              <CardItem>              
                <Body>
                  <Text>
                  {'Rp. '+this.state.HargaBarang} 
                  </Text>
                </Body>           
              </CardItem>
            </Card>
              
            <Card style={{flex: 0}}>
              <CardItem>              
                <Body>
                  <Text>
                    {'Keterangan : '}  
                  </Text>
                  <Text>
                    {this.state.DeskripsiBarang}  
                  </Text>
                </Body>           
              </CardItem>
            </Card>
  
            <Card style={{flex: 0}}>
              <CardItem>              
                <Body>
                  <Text>
                  {'Stok : '+this.state.StokBarang}  
                  </Text>          
                </Body>           
              </CardItem>
            </Card>


            <Card style={{flex: 0}}>
              <CardItem>              
                <Body>
                <Item regular>
                      <Input placeholder='Jumlah'
                        keyboardType="numeric"
                        onChangeText={(InputJumlah) => this.setState({InputJumlah})}
                        value={this.state.InputJumlah}
                                              
                      />
                </Item>  
                  
                </Body>           
              </CardItem>
            </Card>
  
                <Button
                  onPress={this.order.bind(this)}
                  title="Beli"
                  color="#841584"
                />           
            </Card>
           
            </KeyboardAvoidingView>
          </Content>
         
        </Container>
        
       
      );
    }
  }

  export default connect()(Barang);