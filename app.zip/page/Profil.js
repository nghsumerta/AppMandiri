import React, { Component } from 'react';
import {  Button,Image, View, ListView, ActivityIndicator, FlatList, Alert, Platform, TextInput, AsyncStorage} from 'react-native';
import {Container, Header, Content, Card, CardItem, Thumbnail, Text, Icon, Left, Body, List, Label, Input, Item, ListItem, Right, Form } from 'native-base';
import { Ionicons } from '@expo/vector-icons';
import { TabNavigator, TabBarBottom, StackNavigator } from 'react-navigation';
import { Col, Row, Grid } from 'react-native-easy-grid';


import Kategori from './Kategori';
import Order from './Order';


class Profil extends React.Component {

    constructor(props){
      super(props)
  
      this.state = {
        NamaMember : '',      
        HutangMember: '',
  
      }
    }



    logout = () => {

      this.props.navigation.navigate('login');

    }
    



  componentDidMount(){
    fetch('https://bebaskan.id/android/filterlogin.php',{
          method: 'POST',
          headers: {
            'Accept' : 'application/json',
            'Content-Type' : 'application/json',
          },
          body: JSON.stringify({
            nik: this.props.navigation.state.params.NIK,            
          })
    })
    .then((response) => response.json() )
    .then((responseJson) => {
     
      AsyncStorage.setItem('idMember',responseJson[0].member_id);
      
      this.setState ({  
         

        NamaMember : responseJson[0].nama_member,
        HutangMember : responseJson[0].info_hutang,
        NIK : responseJson[0].nik,
        MEMBER_ID : responseJson[0].member_id,

      })

    })

    .catch((error) =>{
      console.error(error);
     
    });
  }

  render() {
    
    return (
      
      
      <Container>
        <Header style={{backgroundColor: 'white'}} />
        <Content>
          <Card>
            <CardItem style={{alignItems:'center', flexGrow:1, justifyContent:'center', margin:10}}>              
              <Text>PROFIL MEMBER</Text>            
             </CardItem>
           </Card>
           <Card>
            <CardItem>              
              <Image source={{uri: 'https://steemit-production-imageproxy-thumbnail.s3.amazonaws.com/U5dryadKZSx4FHRejQeuyZT4h17N7QJ_1680x8400'}} style={{height: 400, width: 300, flex: 1, borderRadius:30}}/>            
             </CardItem>
           </Card>
           <Card>
            <CardItem>              
              <Text>{'Nama Member : '+this.state.NamaMember}</Text>            
             </CardItem>
           </Card>
           <Card>
            <CardItem>              
              <Text>{'Info Hutang : '+this.state.HutangMember}</Text>            
             </CardItem>
           </Card>
           <Card>
            <CardItem>              
              <Text>{'NIK : '+this.state.NIK}</Text>            
             </CardItem>             
           </Card>
          <Card>
            <Button
              onPress={this.logout}
              title="logout"

            />
          </Card>
        </Content>
      </Container>


    );
  }
}






export default TabNavigator(
  { 
    Profil : { screen: Profil },
    Kategori: { screen: Kategori },    
    Order: { screen: Order },
    
  },

  {
    navigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, tintColor }) => {
        const { routeName } = navigation.state;
        let iconName;
        if (routeName === 'Kategori') {
          iconName = `ios-apps${focused ? '' : '-outline'}`;
        } else if (routeName === 'Order') {
          iconName = `ios-cart${focused ? '' : '-outline'}`;
        }  else if (routeName === 'Profil') {
            iconName = `ios-contacts${focused ? '' : '-outline'}`;
          } 

        // You can return any component that you like here! We usually use an
        // icon component from react-native-vector-icons
        return <Ionicons name={iconName} size={25} color={tintColor} />;
      },

    }),

    tabBarComponent: TabBarBottom,
    tabBarPosition: 'bottom',
    tabBarOptions: {
      activeTintColor: 'tomato',
      inactiveTintColor: 'gray',
    },
    animationEnabled: false,
    swipeEnabled: false,
  }
);