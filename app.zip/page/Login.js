import React from 'react';
import {
    Image,
    StyleSheet,
    Text,
    View,
    Alert,
    AsyncStorage,
    ActivityIndicator,
    Keyboard,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
} from 'react-native';
import { StackNavigator } from 'react-navigation';
import { Container, Header, Content, Card, CardItem, Body, Form, Item, Input, Label, Button } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';


export default class Login extends React.Component {

    constructor(props){

        super(props)
        this.state = {
            inputNIK: '',
            inputPass: '',
            isLoading : false,
        }
    }

    

    
    login = () => {

        const { inputNIK }  = this.state ;
        const { inputPass }  = this.state ;
       
        this.setState({
            isLoading : true
        });
        
        fetch('http://bebaskan.id/android/login.php', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                nik: this.state.inputNIK,
                password: this.state.inputPass,
            })
        })

        .then((response) => response.json())
        .then ((res) => {
            if(res === 'Ok' )
             {
    
                this.props.navigation.navigate('Profil', { 

                    NIK: inputNIK

                 });
                
               
            }
            else {
                Alert.alert(res);
                this.setState({
                    isLoading : false
                })
            }
        })
        .done();
    }

    


    render(){
        return (
           
            <Container style={{flex: 1 , backgroundColor:'#560027'}}>
                <Header style={{backgroundColor: '#880e4f'}}/>
                    <Content>
                    <KeyboardAvoidingView behavior="padding">
                    
                    <Body style={{alignItems:'center', flexGrow:1, justifyContent:'center', marginTop:30}}>
                        <Image 
                            style={{width:408, height:224}}
                            source={require('../gambar/logo.png')} />

                        <Text style={{color:'white', marginTop: 10, marginBottom:10, width:160, textAlign:'center',opacity:0.9}}> Login Sistem </Text>
                    </Body> 
                         
                    <Body>

                    <CardItem style={{backgroundColor:'#560027'}}>
                            <Body>
                                <Grid>
                                    <Col style={{backgroundColor: 'white', height: 175, borderRadius:20, marginBottom:20, paddingBottom:0}}>
                                    <Form>
                                        <Item floatingLabel>
                                            <Label>No Induk Kependudukan</Label>
                                        <Input
                                            keyboardType="numeric"
                                            onChangeText={inputNIK => this.setState({inputNIK})}

                                        />
                                        </Item>
                                        <Item floatingLabel last>
                                            <Label>Password</Label>
                                        <Input
                                            onChangeText={(inputPass) => this.setState({inputPass})}
                                            secureTextEntry={true}
                                        />
                                        </Item>
                                    </Form>
                                    </Col>
                                </Grid>
                                <Grid>
                                    <Col>
                                         
                                        <Button block danger onPress={this.login}>{this.state.isLoading ? <ActivityIndicator animating={true} color='white' size={20}  />  : <Text style={{fontSize: 20, color:'white'}}> Login </Text>}</Button>                   
                                    </Col>
                                </Grid>
                                
                            </Body>
                            
                        </CardItem>          

                        

                    </Body>               
                    </KeyboardAvoidingView>
                    </Content>
            </Container>
            
        );
    }

}

