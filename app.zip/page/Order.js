import React from 'react';
import {
    Image,
    StyleSheet,
    Text,
    View,
    Alert,
    AsyncStorage,
    ActivityIndicator,
    Keyboard,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
} from 'react-native';
import { StackNavigator } from 'react-navigation';
import { Container, Header, Content, Card, CardItem, Body, Form, Item, Input, Label, Button,Left,Right } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';
import {getOrder} from '../api/Api';
import {connect} from 'react-redux';



class Order extends React.Component {   


  static navigationOptions = {
    title: 'Order'
  };

  constructor(props){
    super(props);
    this.state = {
      isLoading : true,
    }
  }


componentDidMount(){

  AsyncStorage.getItem('idMember').then(id => {
    getOrder(id,json => {
      this.props.dispatch({type: "UPDATE",data : json});
      this.setState({
        isLoading : false
      })
    })
  })
}


    render() {    




      let total = 0;
      let listData = this.props.data;
      let lists = [];
      listData.forEach((value,key) => {
        total = total + parseInt(value.total_bayar);
        lists.push(
          <Card style={{padding: 10}} key={key} >
            <Grid>
              <Col style={{height: 75, width: 62}}>
                <Image source={{uri: 'http://bebaskan.id/gambar/'+value.gambar}} style={{height: 75, width: 62}}/>                
              </Col>
              <Col style={{marginLeft:15 }} >
                <Text style={{fontSize: 20,fontWeight:'bold'}} >{value.nama_barang}</Text>
                <Text style={{fontSize: 15}} >{value.jumlah_barang+" X "+value.harga_barang}</Text>
                <Text style={{fontSize: 15,fontWeight:'bold'}} >{value.total_bayar}</Text>
                <Text style={{fontSize: 15,fontWeight:'bold', color: 'red'}} >{'Status Order => '+value.status_id}</Text>                
              </Col>
            </Grid>
             
          </Card>
          
        )
      })

      return (
        this.state.isLoading ? <View style={{
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          position: 'absolute',
          alignItems: 'center',
          justifyContent: 'center'
        }}>

          <ActivityIndicator animating={true} size="large" />

        </View>
        :
        <Container>
          <Content >                   
            {lists}
            <Card>
              <CardItem>
                <Text style={{fontSize: 15}}>{'Total Bayar : ' + total}</Text>
              </CardItem>
            </Card>
          </Content>
        </Container>
      )
    }
  }


const mapStateToProps = (state) => {
  return {
    data : state.order
  }
}

const redux = connect(mapStateToProps)(Order);

export default StackNavigator({
  order : {screen : redux}
})

