import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { StackNavigator,SwitchNavigator } from 'react-navigation';
import {createStore} from 'redux';
import {Provider} from 'react-redux';
import Login from './page/Login';
import Profil from './page/Profil';
import {reducer} from './reducer/Main';

const store = createStore(reducer);

const Main = StackNavigator ({
  Profil: { screen: Profil },
  }, {
    navigationOptions: {
      header: false,
    }
  
});

const Auth = StackNavigator({
  login : { screen: Login },
},{
  navigationOptions: {
    header: false,
  }
});

const Application = SwitchNavigator({
  main : {screen : Main},
  login : {screen : Auth},
},{
  initialRouteName: 'login',
})

export default class App extends React.Component {
  render() {
    return (
      <Provider store={store}>
        <Application />
      </Provider>
    );
  }
}

